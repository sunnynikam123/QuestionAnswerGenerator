import React from 'react'
import { Route, Routes, Link } from 'react-router-dom';
import Home from './components/Home';
import NotFound from './components/NotFound'
import Scan from './components/Scan';
import Ui from './components/Ui';
function App() {
  return (
    <div className=" mt-[72px] sm:ml-64 bodyp">

    <Routes>
          <Route path="/" element={<Home/>} />
          <Route path="*" element={<NotFound />} />
          <Route path="/ui" element={<Ui />} />
          <Route path="/scan/tuning/:tuningValue/test/:testValue/target/:url" element={<Scan />} /> 
    </Routes>
    </div>
  )
}
document.getElementsByTagName("body")[0].classList.add("dark")

export default App