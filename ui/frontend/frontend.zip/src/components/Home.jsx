import React from 'react'
import { useState } from "react"
import { useNavigate } from "react-router-dom";
import slugify from 'slugify';
import texture from '../assets/texture_op.jpg'
function Home() {
  const navigate = useNavigate();
  const [tuning, settuning] = useState("1")
  const [agree, setagree] = useState(false)
  const [Text, setText] = useState("Interesting File / Seen in logs")
  const [url, seturl] = useState("NULL")
  const handletuning = (e) => {
    const newValue = e.target.value;
    const selectedOption = e.target.selectedOptions[0];
    const optionText = selectedOption.textContent || selectedOption.innerText;

    settuning(newValue);
    setText(optionText);

  };

  const agreeterms = ()=>{

    setagree(!agree) 
  }
  const scan = () => {
    if(agree){

      const encodedTuning = encodeURIComponent(tuning);
      var encodedText = encodeURIComponent(Text);
      var encodedUrl = encodeURIComponent(url);
      encodedText = slugify(Text, { lower: true, strict: true })
      navigate(`/scan/tuning/${encodedTuning}/test/${encodedText}/target/${encodedUrl}`)
    }
    else{
      alert("you have not agreed to terms and conditions")
    }
  }
  return (
    <>
      <div className="form flex flex-col justify-center items-center h-[calc(100vh-56px)] relative">
        <img src={texture} alt="" className=" absolute top-0 right-0 w-[110%] h-full opacity-[30%]" style={{ filter: 'invert(100)', mixBlendMode: 'plus-lighter' }} />
        <div className=" w-[40rem] p-4 h-80 rounded-lg flex flex-col justify-center items-center bg-slate-100 dark:bg-slate-800">

          <div className="cont relative">

            <input type="text" placeholder="Enter Target Url" className="dark:bg-slate-800 border-4 w-[30rem] outline-none border-solid border-slate-400 dark:border-slate-400  rounded-tl-lg rounded-bl-lg rounded-tr-lg rounded-br-lg text-2xl py-2 px-2"
              onChange={(e) => { seturl(e.target.value) }}

            />
            <select className=" absolute w-36 top-0 right-0 border-4 outline-none border-solid border-slate-400 dark:border-slate-400 rounded-tr-lg rounded-br-lg text-2xl py-2 px-2 bg-slate-300 dark:bg-slate-800" onChange={handletuning}>
              <option value="1">Interesting File / Seen in logs</option>
              <option value="2">Misconfiguration / Default File</option>
              <option value="3">Information Disclosure</option>
              <option value="4">Injection (XSS/Script/HTML)</option>
              <option value="5">Remote File Retrieval - Inside Web Root</option>
              <option value="6">Denial of Service</option>
              <option value="7">Remote File Retrieval - Server Wide</option>
              <option value="8">Command Execution / Remote Shell</option>
              <option value="9">SQL Injection</option>
            </select>
            {/* <div class="flex items-center m-5 dark:bg-slate-900 p-2 rounded-lg"> */}
            <div class="flex items-center my-2 p-2 rounded-lg w-full ">
              <input id="default-checkbox" type="checkbox" checked={agree} onChange={agreeterms} class="mx-2 w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600" />
              <label for="default-checkbox" class="ms-2 text-sm text-[1.1rem] text-gray-900 dark:text-gray-300">I Consent I am authorized to scan this target</label>
            </div>

            <div className="sca flex flex-col">
              <button className="self-center dark:bg-slate-850 px-2 py-2 text-xl rounded-xl border-4 border-solid flex items-center justify-center border-slate-400 dark:border-slate-400" onClick={scan}>
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="size-6 mx-2">
                  <path fillRule="evenodd" d="M7.5 3.75A1.5 1.5 0 0 0 6 5.25v13.5a1.5 1.5 0 0 0 1.5 1.5h6a1.5 1.5 0 0 0 1.5-1.5V15a.75.75 0 0 1 1.5 0v3.75a3 3 0 0 1-3 3h-6a3 3 0 0 1-3-3V5.25a3 3 0 0 1 3-3h6a3 3 0 0 1 3 3V9A.75.75 0 0 1 15 9V5.25a1.5 1.5 0 0 0-1.5-1.5h-6Zm10.72 4.72a.75.75 0 0 1 1.06 0l3 3a.75.75 0 0 1 0 1.06l-3 3a.75.75 0 1 1-1.06-1.06l1.72-1.72H9a.75.75 0 0 1 0-1.5h10.94l-1.72-1.72a.75.75 0 0 1 0-1.06Z" clipRule="evenodd" />
                </svg>
                Start Scan</button>
            </div>
          </div>
        </div>
      </div>
    </>)
}

export default Home